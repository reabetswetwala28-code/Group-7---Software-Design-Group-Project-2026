
package todolist;

/**
 *
 * @author Lenovo
 */


import java.awt.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.*;

public class Task extends JPanel {

    private JLabel indexLabel;
    private JTextField taskField;
    private JComboBox<String> categoryBox;
    private JComboBox<String> priorityBox;
    private JTextField dueDateField;
    private JButton doneBtn;
    private JButton removeBtn;
    private boolean completed = false;

    public Task() {
        setPreferredSize(new Dimension(880, 42));
        setBackground(new Color(225, 234, 17));
        setLayout(new GridLayout(1, 7, 6, 0));

        // Index
        indexLabel = new JLabel(" ");
        indexLabel.setHorizontalAlignment(JLabel.CENTER);
        indexLabel.setOpaque(true);
        indexLabel.setBackground(new Color(255, 234, 17));
        indexLabel.setFont(new Font("Sans-serif", Font.BOLD, 13));
        add(indexLabel);

        // Task name
        taskField = new JTextField("Enter task...");
        taskField.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        taskField.setBackground(new Color(255, 234, 17));
        add(taskField);

        // Category
        String[] categories = {"Work", "Personal", "Study", "Shopping", "Health", "Other"};
        categoryBox = new JComboBox<>(categories);
        add(categoryBox);

        // Priority
        String[] priorities = {"High", "Medium", "Low"};
        priorityBox = new JComboBox<>(priorities);
        priorityBox.setSelectedItem("Medium");
        priorityBox.addActionListener(e -> updateColours());
        add(priorityBox);

        // Due Date
        dueDateField = new JTextField("YYYY-MM-DD");
        dueDateField.setHorizontalAlignment(JTextField.CENTER);
        dueDateField.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        dueDateField.setBackground(Color.WHITE);
        dueDateField.addActionListener(e -> updateColours());
        add(dueDateField);

        // Done
        doneBtn = new JButton("Done");
        doneBtn.setFocusPainted(false);
        add(doneBtn);

        // Remove
        removeBtn = new JButton("Remove");
        removeBtn.setFocusPainted(false);
        add(removeBtn);

        updateColours();
    }

    private void updateColours() {
        if (completed) return;

        Color bg = new Color(225, 234, 17); // default yellow

        String priority = (String) priorityBox.getSelectedItem();
        if ("High".equals(priority)) {
            bg = new Color(255, 120, 120);
        } else if ("Medium".equals(priority)) {
            bg = new Color(255, 190, 100);
        } else if ("Low".equals(priority)) {
            bg = new Color(160, 230, 160);
        }

        // Check due date for reminder highlighting
        try {
            LocalDate due = LocalDate.parse(dueDateField.getText().trim());
            LocalDate today = LocalDate.now();
            if (due.isBefore(today) || due.isEqual(today)) {
                // Overdue or due today → stronger red tint
                bg = new Color(255, 80, 80);
            }
        } catch (DateTimeParseException ignored) {
            // invalid date – keep priority colour
        }

        setBackground(bg);
        indexLabel.setBackground(bg);
        taskField.setBackground(bg);
    }

    public void setIndex(int index) {
        indexLabel.setText(String.valueOf(index));
    }

    public JButton getDoneBtn() { return doneBtn; }
    public JButton getRemoveBtn() { return removeBtn; }

    public void markAsDone() {
        completed = true;
        Color green = new Color(100, 200, 100);
        setBackground(green);
        indexLabel.setBackground(green);
        taskField.setBackground(green);
        categoryBox.setEnabled(false);
        priorityBox.setEnabled(false);
        dueDateField.setEnabled(false);
        doneBtn.setEnabled(false);
        revalidate();
        repaint();
    }

    // ----- Persistence helpers -----
    public TaskData toData() {
        return new TaskData(
                taskField.getText(),
                (String) categoryBox.getSelectedItem(),
                (String) priorityBox.getSelectedItem(),
                dueDateField.getText(),
                completed
        );
    }

    public static Task fromData(TaskData data) {
        Task t = new Task();
        t.taskField.setText(data.taskName);
        t.categoryBox.setSelectedItem(data.category);
        t.priorityBox.setSelectedItem(data.priority);
        t.dueDateField.setText(data.dueDate);
        if (data.completed) {
            t.markAsDone();
        } else {
            t.updateColours();
        }
        return t;
    }
}

// Simple serializable data holder
class TaskData implements Serializable {
    private static final long serialVersionUID = 1L;
    String taskName, category, priority, dueDate;
    boolean completed;

    public TaskData(String taskName, String category, String priority, String dueDate, boolean completed) {
        this.taskName = taskName;
        this.category = category;
        this.priority = priority;
        this.dueDate = dueDate;
        this.completed = completed;
    }
}