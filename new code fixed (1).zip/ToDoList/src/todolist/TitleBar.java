
package todolist;

/**
 *
 * @author Lenovo
 */



import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TitleBar extends JPanel {
    public TitleBar() {
        setPreferredSize(new Dimension(900, 80));
        setBackground(new Color(90, 143, 123));

        JLabel title = new JLabel("TO DO LIST APP");
        title.setFont(new Font("Sans-serif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setHorizontalAlignment(JLabel.CENTER);
        add(title);
    }
}