
package todolist;

/**
 *
 * @author Lenovo
 */
 
     


import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class List extends JPanel {

    public List() {
        GridLayout layout = new GridLayout(15, 1);
        layout.setVgap(6);
        setLayout(layout);
        setBackground(new Color(245, 245, 245));
    }

    public void updateIndexes() {
        int index = 1;
        for (Component c : getComponents()) {
            if (c instanceof Task) {
                ((Task) c).setIndex(index++);
            }
        }
    }
}