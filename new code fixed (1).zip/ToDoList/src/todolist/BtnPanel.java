
package todolist;

/**
 *
 * @author Lenovo
 */



import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;

public class BtnPanel extends JPanel {

    private JButton addTaskBtn, clearBtn, saveBtn, loadBtn;

    public BtnPanel() {
        setPreferredSize(new Dimension(900, 80));
        setBackground(new Color(129, 202, 207));

        Font btnFont = new Font("Sans-serif", Font.PLAIN, 16);

        addTaskBtn = createButton("Add Task", btnFont);
        clearBtn   = createButton("Clear All", btnFont);
        saveBtn    = createButton("Save", btnFont);
        loadBtn    = createButton("Load", btnFont);

        add(addTaskBtn);
        add(Box.createHorizontalStrut(15));
        add(clearBtn);
        add(Box.createHorizontalStrut(40));
        add(saveBtn);
        add(Box.createHorizontalStrut(15));
        add(loadBtn);
    }

    private JButton createButton(String text, Font font) {
        JButton btn = new JButton(text);
        btn.setFont(font);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        return btn;
    }

    public JButton getAddTaskBtn() { return addTaskBtn; }
    public JButton getClearBtn()   { return clearBtn; }
    public JButton getSaveBtn()    { return saveBtn; }
    public JButton getLoadBtn()    { return loadBtn; }
}