package todolist;

/**
 *
 * @author Lenovo
 */



import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class AppFrame extends JFrame {

    private JButton addTaskBtn, clearBtn, saveBtn, loadBtn;
    private TitleBar titleBar;
    private BtnPanel btnPanel;
    private List taskList;

    public AppFrame() {
        titleBar = new TitleBar();
        btnPanel = new BtnPanel();
        taskList = new List();

        setTitle("To-Do List App");
        setSize(900, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        add(titleBar, "North");
        add(taskList, "Center");
        add(btnPanel, "South");

        addTaskBtn = btnPanel.getAddTaskBtn();
        clearBtn   = btnPanel.getClearBtn();
        saveBtn    = btnPanel.getSaveBtn();
        loadBtn    = btnPanel.getLoadBtn();

        addListeners();
    }

    private void addListeners() {
        // Add Task
        addTaskBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Task task = new Task();
                taskList.add(task);
                taskList.updateIndexes();
                revalidate();
                repaint();

                // Done
                task.getDoneBtn().addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        task.markAsDone();
                        revalidate();
                        repaint();
                    }
                });

                // Remove
                task.getRemoveBtn().addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        taskList.remove(task);
                        taskList.updateIndexes();
                        revalidate();
                        repaint();
                    }
                });
            }
        });

        // Clear All – with confirmation dialog
        clearBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int choice = JOptionPane.showConfirmDialog(
                    AppFrame.this,
                    "Are you sure you want to clear all tasks?",
                    "Confirm Clear",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    for (Component c : taskList.getComponents()) {
                        if (c instanceof Task) {
                            taskList.remove(c);
                        }
                    }
                    taskList.updateIndexes();
                    revalidate();
                    repaint();
                }
            }
        });

        // Save tasks
        saveBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                saveTasks();
            }
        });

        // Load tasks
        loadBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                loadTasks();
            }
        });
    }

    private void saveTasks() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("tasks.dat"))) {
            ArrayList<TaskData> dataList = new ArrayList<>();
            for (Component c : taskList.getComponents()) {
                if (c instanceof Task) {
                    dataList.add(((Task) c).toData());
                }
            }
            out.writeObject(dataList);
            JOptionPane.showMessageDialog(this, "Tasks saved successfully!\nYou can copy tasks.dat to another device.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadTasks() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("tasks.dat"))) {
            for (Component c : taskList.getComponents()) {
                if (c instanceof Task) taskList.remove(c);
            }

            ArrayList<TaskData> dataList = (ArrayList<TaskData>) in.readObject();
            for (TaskData data : dataList) {
                Task task = Task.fromData(data);
                taskList.add(task);

                task.getDoneBtn().addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        task.markAsDone();
                        revalidate();
                        repaint();
                    }
                });
                task.getRemoveBtn().addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        taskList.remove(task);
                        taskList.updateIndexes();
                        revalidate();
                        repaint();
                    }
                });
            }
            taskList.updateIndexes();
            revalidate();
            repaint();
            JOptionPane.showMessageDialog(this, "Tasks loaded successfully!");
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "No saved file found (tasks.dat)");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading: " + ex.getMessage());
        }
    }
}